sap.ui.define([
    './BaseController',
    'sap/ui/model/json/JSONModel',
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageToast"
], function (BaseController, JSONModel, Filter, FilterOperator, MessageToast) {

    "use strict";

    return BaseController.extend("zgpms.meilpower.com.controller.Gatepasslist", {

        onInit: function () {
            // Filter bar model
            var oFilterModel = new JSONModel({
                GatePassType: "NRGP",
                FromDate: null,
                ToDate: null,
                Status: "All",
                GatePassReqNo: "",
                GatePassNo: ""
            });
            this.getView().setModel(oFilterModel, "filterModel");

            // View model for UI state
            var oViewModel = new JSONModel({
                activeTab: "Requests"
            });
            this.getView().setModel(oViewModel, "viewModel");

            // Model for the second tab (Gate Passes)
            var oHeaderModel = new JSONModel({ gatePassHeaders: [] });
            this.getView().setModel(oHeaderModel, "headerModel");

            // Initial load trigger
            this.onSearch();
        },

        onAfterRendering: function () {
            // Load gate pass list after rendering to ensure bindings are ready
            this.onSearch();
        },


        onRefresh: function () {
            this.onSearch();
        },

        onRefreshHeaders: function () {
            this._loadGatePassHeaders();
        },

        onMainTabSelect: function (oEvent) {
            var sKey = oEvent.getParameter("key");
            this.getView().getModel("viewModel").setProperty("/activeTab", sKey);

            var oLabel = this.byId("idSearchLabel");
            var oSearchField = this.byId("idSearchField");

            if (sKey === "Requests") {
                if (oLabel) oLabel.setText("Request Number");
                if (oSearchField) {
                    oSearchField.setPlaceholder("Search Request No...");
                    oSearchField.bindProperty("value", "filterModel>/GatePassReqNo");
                }
            } else {
                if (oLabel) oLabel.setText("Gate Pass Number");
                if (oSearchField) {
                    oSearchField.setPlaceholder("Search Gate Pass No...");
                    oSearchField.bindProperty("value", "filterModel>/GatePassNo");
                }
            }
            
            // Delay search to ensure model/UI updates are processed
            setTimeout(function() {
                this.onSearch();
            }.bind(this), 200);
        },

        _loadGatePassHeaders: function () {
            var oTable = this.byId("gatePassHeaderTable");
            this.onSearch();
        },

        onSearch: function (oEvent) {
            var oModel = this.getView().getModel("filterModel");
            if (!oModel) return;
            var oFilterData = oModel.getData();
            
            var oTabField = this.byId("idMainIconTabBar");
            var sTabKey = oTabField ? oTabField.getSelectedKey() : "Requests";
            
            // If triggered by liveChange, update the model value manually
            if (oEvent && oEvent.getParameter("newValue") !== undefined) {
                var sNewValue = oEvent.getParameter("newValue");
                if (sTabKey === "Requests") {
                    oModel.setProperty("/GatePassReqNo", sNewValue);
                    oFilterData.GatePassReqNo = sNewValue;
                } else {
                    oModel.setProperty("/GatePassNo", sNewValue);
                    oFilterData.GatePassNo = sNewValue;
                }
            }

            var aFilters = [];
            var sType = oFilterData.GatePassType || "All";
            aFilters.push(new Filter("GatePassType", FilterOperator.EQ, sType));

            if (sTabKey === "Requests") {
                // Requests Tab
                var aRequestFilters = aFilters.slice();
                var sStatus = oFilterData.Status || "All";
                aRequestFilters.push(new Filter("Status", FilterOperator.EQ, sStatus));

                if (oFilterData.GatePassReqNo) {
                    aRequestFilters.push(new Filter("GatePassReqNo", FilterOperator.Contains, oFilterData.GatePassReqNo));
                }
                this._loadGatePassList(aRequestFilters);
            } else {
                // Gate Passes Tab
                var aHeaderFilters = aFilters.slice();
                if (oFilterData.GatePassNo) {
                    aHeaderFilters.push(new Filter("GatePassNo", FilterOperator.Contains, oFilterData.GatePassNo));
                }
                this._loadGatePassHeaderList(aHeaderFilters);
            }
        },

        _loadGatePassList: function (aFilters) {
            var oTable = this.byId("gatePassTable");
            if (!oTable) return;
            var oBinding = oTable.getBinding("items");
            if (oBinding) {
                oBinding.filter(aFilters);
            }
        },

        _loadGatePassHeaderList: function (aFilters) {
            var oODataModel = this.getOwnerComponent().getModel();
            var oHeaderModel = this.getView().getModel("headerModel");
            var oFilterData = this.getView().getModel("filterModel").getData();

            console.log("Fetching Gate Pass Headers...");

            oODataModel.read("/GatePassHDRSet", {
                filters: aFilters,
                success: function (oData) {
                    var aResults = oData.results;

                    // Apply LOCAL filtering for GatePassNo if it's provided in the search field
                    if (oFilterData.GatePassNo) {
                        var sSearch = oFilterData.GatePassNo.toLowerCase();
                        aResults = aResults.filter(function(item) {
                            return item.GatePassNo && item.GatePassNo.toLowerCase().indexOf(sSearch) !== -1;
                        });
                    }

                    console.log("Gate Pass Headers after local filter:", aResults.length);
                    oHeaderModel.setProperty("/gatePassHeaders", aResults);
                },
                error: function (oError) {
                    console.error("Failed to fetch Gate Pass Headers", oError);
                }
            });
        },

        onClear: function () {
            this.getView().getModel("filterModel").setData({
                GatePassType: "NRGP",
                FromDate: null,
                ToDate: null,
                Status: "All",
                GatePassReqNo: ""
            });
            this.onSearch();
        },

        onCreate: function () {
            this.getOwnerComponent().getRouter().navTo("GatePassRequestCreation");
        },

        onCreateGatePass: function () {
            this.getOwnerComponent().getRouter().navTo("GatePassCreation", { reqNo: "" });
        },

        onItemPress: function (oEvent) {
            var oItem = oEvent.getSource();
            var oContext = oItem.getBindingContext();
            var sReqNo = oContext.getProperty("GatePassReqNo");

            this.getOwnerComponent().getRouter().navTo("GatePassRequestCreation", {
                reqNo: sReqNo
            });
        }
    });
});
